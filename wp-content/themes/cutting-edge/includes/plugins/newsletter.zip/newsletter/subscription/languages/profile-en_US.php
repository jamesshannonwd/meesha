<?php

$options = array();
$options['email'] = 'Email';
$options['email_error'] = 'The email is not correct';
$options['name'] = 'Name';
$options['name_error'] = 'The name is not correct';
$options['surname'] = 'Last name';
$options['surname_error'] = 'The last name is not correct';
$options['sex'] = 'I\'m';
$options['privacy'] = 'Subscribing I accept the privacy rules of this site';
$options['privacy_error'] = 'You must accept the privacy statement';
$options['subscribe'] = 'Subscribe';
$options['save'] = 'Save';

$options['title_female'] = 'Mrs.';
$options['title_male'] = 'Mr.';
$options['title_none'] = 'Dear';

$options['sex_male'] = 'Man';
$options['sex_female'] = 'Woman';
$options['sex_none'] = 'None';
