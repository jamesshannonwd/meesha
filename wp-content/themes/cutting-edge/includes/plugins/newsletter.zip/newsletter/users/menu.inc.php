<h5>Subscribers Management Module</h5>

<div id="newsletter-nav">
    <a class="button" href="<?php echo $module->get_admin_page_url('index'); ?>">Search</a>
    <!--<a class="button" href="<?php echo $module->get_admin_page_url('index'); ?>">Old search</a>-->
    <a class="button" href="<?php echo $module->get_admin_page_url('new'); ?>">New subscriber</a>
    <a class="button" href="<?php echo $module->get_admin_page_url('massive'); ?>">Massive changes</a>
    <a class="button" href="<?php echo $module->get_admin_page_url('stats'); ?>">Statistics</a>
    <a class="button" href="<?php echo $module->get_admin_page_url('import'); ?>">Import</a>
    <a class="button" href="<?php echo $module->get_admin_page_url('export'); ?>">Export</a>
</div>